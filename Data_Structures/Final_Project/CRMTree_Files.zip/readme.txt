To Whom it may concern:

Here are the three files that make up my final project, the binary search tree customer relationship management system. A couple things, the code as a whole doesn't run yet as I
am still in the process of debugging the CRM.cpp file. So that will have to be graded by looking at the code directly. However, if I do say so myself I have a pretty awesome
menu that you can mess around with if you comment out the indicated lines and compile only the driver file instead of the driver and the CRM.cpp file. I should have all of these
bugs fixed by Thursday so that I can present my project. I did have a bit of trouble with the deletion of nodes, but I think I figured it out in the end! I am super excited to show
it off and show everybody how cool and useful this program can be. I hope you enjoy my logic and what the program sets out to be!

Thank you,
Michael Rogers (Autor)
